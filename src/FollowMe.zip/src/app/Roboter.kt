
data class Robot(val robotName : String)
